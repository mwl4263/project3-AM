﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Project3_FinalExam.Models;

namespace Project3_FinalExam.ViewModels
{
    public class UndergradViewModel
    {
        public List<UnderGradMajors> UnderGrads { get; set; }
        public string Title { get; set; }
    }
}
